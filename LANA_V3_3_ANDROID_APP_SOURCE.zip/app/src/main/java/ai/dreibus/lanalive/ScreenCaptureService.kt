package ai.dreibus.lanalive

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Parcelable
import android.util.Log
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

class ScreenCaptureService : Service() {
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private lateinit var captureThread: HandlerThread
    private lateinit var captureHandler: Handler
    private var lastFrameAt = 0L
    private var serverUrl: String = ""

    override fun onCreate() {
        super.onCreate()
        captureThread = HandlerThread("LanaScreenCapture").also { it.start() }
        captureHandler = Handler(captureThread.looper)
        val channelId = "lana_live_capture"
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(channelId, "LANA LIVE", NotificationManager.IMPORTANCE_LOW)
        )
        val notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("LANA LIVE")
            .setContentText("Лана видит экран")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .build()
        startForeground(
            1001,
            notification,
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (projection != null) return START_NOT_STICKY

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val resultData = intent?.parcelableExtra<Intent>(EXTRA_RESULT_DATA)
        serverUrl = intent?.getStringExtra(EXTRA_SERVER_URL).orEmpty().trimEnd('/')
        if (resultCode == 0 || resultData == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        val manager = getSystemService(MediaProjectionManager::class.java)
        projection = manager.getMediaProjection(resultCode, resultData).also { mediaProjection ->
            mediaProjection.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() = releaseCapture()
            }, captureHandler)
        }
        startScreenCapture()
        return START_NOT_STICKY
    }

    private fun startScreenCapture() {
        val windowManager = getSystemService(WindowManager::class.java)
        val metrics = resources.displayMetrics
        val bounds = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            windowManager.currentWindowMetrics.bounds
        } else null
        val width = bounds?.width() ?: metrics.widthPixels
        val height = bounds?.height() ?: metrics.heightPixels
        val density = metrics.densityDpi

        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2).apply {
            setOnImageAvailableListener({ reader -> captureLatestFrame(reader, width, height) }, captureHandler)
        }

        virtualDisplay = projection?.createVirtualDisplay(
            "LANA-LIVE-SCREEN",
            width,
            height,
            density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface,
            null,
            captureHandler
        )
    }

    private fun captureLatestFrame(reader: ImageReader, width: Int, height: Int) {
        val image = reader.acquireLatestImage() ?: return
        try {
            val now = System.currentTimeMillis()
            if (now - lastFrameAt < FRAME_INTERVAL_MS) return
            lastFrameAt = now

            val plane = image.planes[0]
            val rowPadding = plane.rowStride - plane.pixelStride * width
            val paddedWidth = width + rowPadding / plane.pixelStride
            val padded = Bitmap.createBitmap(paddedWidth, height, Bitmap.Config.ARGB_8888)
            padded.copyPixelsFromBuffer(plane.buffer)
            val frame = Bitmap.createBitmap(padded, 0, 0, width, height)
            padded.recycle()

            FileOutputStream(File(cacheDir, LATEST_FRAME_FILE)).use { output ->
                frame.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, output)
            }
            val jpeg = java.io.ByteArrayOutputStream().use { output ->
                frame.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, output)
                output.toByteArray()
            }
            frame.recycle()
            uploadFrame(jpeg)
        } finally {
            image.close()
        }
    }

    private fun uploadFrame(jpeg: ByteArray) {
        if (serverUrl.isBlank()) return
        try {
            val connection = (URL("$serverUrl/frame").openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 10_000
                readTimeout = 30_000
                doOutput = true
                setRequestProperty("Content-Type", "image/jpeg")
                setFixedLengthStreamingMode(jpeg.size)
            }
            connection.outputStream.use { it.write(jpeg) }
            Log.d(TAG, "Кадр передан LANA: HTTP ${connection.responseCode}")
            connection.disconnect()
        } catch (error: Exception) {
            Log.e(TAG, "Не удалось передать кадр", error)
        }
    }

    private inline fun <reified T : Parcelable> Intent.parcelableExtra(name: String): T? =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            getParcelableExtra(name, T::class.java)
        } else {
            @Suppress("DEPRECATION") getParcelableExtra(name)
        }

    private fun releaseCapture() {
        virtualDisplay?.release()
        virtualDisplay = null
        imageReader?.close()
        imageReader = null
        projection = null
    }

    override fun onDestroy() {
        releaseCapture()
        captureThread.quitSafely()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        const val EXTRA_SERVER_URL = "server_url"
        private const val FRAME_INTERVAL_MS = 3_000L
        private const val JPEG_QUALITY = 72
        private const val LATEST_FRAME_FILE = "lana-latest-screen.jpg"
        private const val TAG = "LanaLive"
    }
}
