package ai.dreibus.lanalive

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.Manifest
import android.content.pm.PackageManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.os.Handler
import android.os.Looper
import java.util.Locale
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var voiceEnabled = false
    private var speaking = false
    private var retryCount = 0
    private var ttsReady = false
    private lateinit var historyView: TextView
    private val history = mutableListOf<String>()
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var serverUrl: EditText

    private val capturePermission = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val service = Intent(this, ScreenCaptureService::class.java).apply {
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, result.data)
                putExtra(ScreenCaptureService.EXTRA_SERVER_URL, serverUrl.text.toString().trim())
            }
            startForegroundService(service)
            status.text = "Разрешение на захват экрана получено. Проверяем связь с сервером."
        } else {
            status.text = "Доступ к экрану не разрешён"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.statusText)
        historyView = findViewById(R.id.historyText)
        val saved = getPreferences(MODE_PRIVATE).getString("voice_history", "").orEmpty()
        if (saved.isNotBlank()) history.addAll(saved.lines().takeLast(30))
        renderHistory()
        tts = TextToSpeech(this) { code ->
            if (code == TextToSpeech.SUCCESS) {
                val languageResult = tts?.setLanguage(Locale("ru", "RU"))
                ttsReady = languageResult != TextToSpeech.LANG_MISSING_DATA && languageResult != TextToSpeech.LANG_NOT_SUPPORTED
                if (!ttsReady) status.text = "Русский голос недоступен: установите голосовой пакет"
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) { speaking = true }
                    override fun onDone(utteranceId: String?) {
                        speaking = false
                        handler.postDelayed({ if (voiceEnabled) listenOnce() }, 500)
                    }
                    override fun onError(utteranceId: String?) {
                        speaking = false
                        handler.postDelayed({ if (voiceEnabled) listenOnce() }, 800)
                    }
                })
            } else { status.text = "Не удалось запустить синтез речи" }
        }
        findViewById<Button>(R.id.voiceButton).setOnClickListener {
            if (voiceEnabled) {
                voiceEnabled = false
                recognizer?.cancel()
                tts?.stop()
                status.text = "Слух остановлен"
            } else if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 501)
            } else startVoice()
        }
        serverUrl = findViewById(R.id.serverUrl)
        serverUrl.setText(getPreferences(MODE_PRIVATE).getString("server_url", ""))
        findViewById<Button>(R.id.startButton).setOnClickListener {
            val url = serverUrl.text.toString().trim()
            if (!url.startsWith("https://")) {
                status.text = "Введите безопасный адрес сервера https://"
                return@setOnClickListener
            }
            getPreferences(MODE_PRIVATE).edit().putString("server_url", url).apply()
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            capturePermission.launch(manager.createScreenCaptureIntent())
        }
    }
    private fun startVoice() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "На устройстве нет службы распознавания речи"
            return
        }
        voiceEnabled = true
        retryCount = 0
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { status.text = "Слушаю: скажи «Лана, ты тут?»" }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
                override fun onError(error: Int) {
                    if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                        voiceEnabled = false
                        status.text = "Нет разрешения на микрофон"
                    } else retryVoice()
                }
                override fun onResults(results: Bundle?) {
                    val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    status.text = "Услышала: $words"
                    if (words.isNotBlank()) appendHistory("Вы: $words")
                    retryCount = 0
                    if (words.contains("лана", ignoreCase = true)) {
                        val answer = if (words.contains("что ты помнишь", ignoreCase = true)) {
                            "Я сохраняю наши последние голосовые обращения на этом планшете."
                        } else "Да, я здесь. Слушаю тебя."
                        appendHistory("Лана: $answer")
                        status.text = "Лана отвечает и продолжит слушать"
                        if (!ttsReady) {
                            status.text = "Голос пока не готов: проверьте русский голос Android"
                            retryVoice()
                        } else {
                            speaking = true
                            val result = tts?.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "lana_reply")
                            if (result != TextToSpeech.SUCCESS) {
                                speaking = false
                                retryVoice()
                            }
                        }
                    } else retryVoice()
                }
            })
        }
        listenOnce()
    }

    private fun appendHistory(line: String) {
        history.add(line)
        while (history.size > 30) history.removeAt(0)
        getPreferences(MODE_PRIVATE).edit().putString("voice_history", history.joinToString("\n")).apply()
        renderHistory()
    }

    private fun renderHistory() {
        historyView.text = if (history.isEmpty()) "История голоса пока пуста" else history.takeLast(8).joinToString("\n")
    }

    private fun listenOnce() {
        if (!voiceEnabled || speaking) return
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        try { recognizer?.startListening(intent) } catch (_: Exception) { status.text = "Ошибка запуска микрофона" }
    }

    private fun retryVoice() {
        if (!voiceEnabled || speaking) return
        retryCount = (retryCount + 1).coerceAtMost(5)
        val delay = (700L * retryCount).coerceAtMost(3500L)
        handler.postDelayed({ if (voiceEnabled && !speaking) listenOnce() }, delay)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 501 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startVoice()
    }

    override fun onDestroy() {
        voiceEnabled = false
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}
