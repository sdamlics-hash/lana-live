package ai.dreibus.lanalive

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var serverUrl: EditText

    private val capturePermission = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val service = Intent(this, ScreenCaptureService::class.java).apply {
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, result.data)
                putExtra(ScreenCaptureService.EXTRA_SERVER_URL, serverUrl.text.toString().trim())
            }
            startForegroundService(service)
            status.text = "Экран подключён"
        } else {
            status.text = "Доступ к экрану не разрешён"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.statusText)
        serverUrl = findViewById(R.id.serverUrl)
        serverUrl.setText(getPreferences(MODE_PRIVATE).getString("server_url", ""))
        findViewById<Button>(R.id.startButton).setOnClickListener {
            val url = serverUrl.text.toString().trim()
            if (!url.startsWith("https://")) {
                status.text = "Введите безопасный адрес сервера https://"
                return@setOnClickListener
            }
            getPreferences(MODE_PRIVATE).edit().putString("server_url", url).apply()
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            capturePermission.launch(manager.createScreenCaptureIntent())
        }
    }
}
